import UserDAO from "../../DAO/UserDAO";

const isUserExist = async (req, res, next) => {
    const userDAO = new UserDAO();
    const id = req.body.userId;

    try {
        const user = await userDAO.findById(id);
        if (!user) {
            res.status(404).json({ error: "User not found" });
            return;
        }
        next();
    } catch (error) {
        res.status(500).json({ error: "Internal Server Error" });
    }
};

export default isUserExist;
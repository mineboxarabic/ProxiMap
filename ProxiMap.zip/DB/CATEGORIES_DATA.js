const CATEGORIES_DATA = [
  {
    _id: ObjectId("65a9a3912f10d0a3fd7106cb"),
    name: "House",
    description: "Test Category Description",
  },
  {
    _id: ObjectId("65a9a3912f10d0a3fd7106c3"),
    name: "Garden",
    description: "Garden Category is for all the garden services",
  },
  {
    _id: ObjectId("65a9a3912f10d0a3fd7106c4"),
    name: "Cleaning",
    description: "Cleaning Category is for all the cleaning services",
  },

  {
    _id: ObjectId("65a9a3912f10d0a3fd7106c5"),
    name: "Plumbing",
    description: "Plumbing Category is for all the plumbing services",
  },

  {
    _id: ObjectId("65a9a3912f10d0a3fd7106c6"),
    name: "Painting",
    description: "Painting Category is for all the painting services",
  },
];

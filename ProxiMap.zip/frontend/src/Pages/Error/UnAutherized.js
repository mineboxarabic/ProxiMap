const UnAutherized = () => {
    return (
        <main>
            <h1>UnAutherized</h1>
        </main>
    )
}

export default UnAutherized
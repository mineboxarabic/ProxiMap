const NotFound = () => {
    return (
        <main>
            <h1>NotFound</h1>
        </main>
    )
}

export default NotFound
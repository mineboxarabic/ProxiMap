import * as React from 'react';

function Footer() {

  return (
    <div className="footer">
      <p>© 2021 - 2022</p>
    </div>

  
  );
}
export default Footer;
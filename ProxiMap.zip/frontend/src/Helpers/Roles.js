export const ADMIN = 'Admin';
export const USER = 'User';
export const PARTNER = 'Partner';
export const MANAGER = 'Manager';
export const STAFF = 'Staff';
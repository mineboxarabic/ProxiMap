/*{
  "_id": {
    "$oid": "65b8d148fc13ae7a5123494c"
  },
  "categoryId": {
    "$oid": "65a9a3912f10d0a3fd7106c5"
  },
  "partnerId": {
    "$oid": "60b5c5b4c7a3c0b4e4f0f8c4"
  },
  "name": "rcleeton0",
  "description": "Colles' fracture of right radius",
  "price": 552,
  "position": {
    "lat": -22.7691646,
    "lng": -43.6950804
  },
  "range": 4,
  "availability": true,
  "status": "accepted"
} */
class Service {
    constructor(){
        this.categoryId = '';
        
    }
}
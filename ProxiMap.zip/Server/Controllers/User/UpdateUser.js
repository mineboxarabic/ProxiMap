import UserDAO from "../../DAO/UserDAO.js";
import ValidateRes from "../../Utilities/ValidateRes.js";

const updateUser = async (req, res) => {
    const userDAO = new UserDAO();
    const id = req.params.id;


    const user = req.body;

   
    const valid = ValidateRes(req);
    if(valid != true) return res.status(400).json(valid);

    //Check if the user exists or not
    const userExists = await userDAO.findById(id);
    if(userExists.error){
        res.status(404).json({error: "User not found"});
        return;
    }

    //Check if the email already exists
    /*const emailExists = await userDAO.findByEmail(user.email);
    if(emailExists){
            res.status(409).json({error: "Email already exists"});
            return;
    }*/
    //Update the user

    const response = await userDAO.updateById(id, user);
    if(response.error){
        if(response.error.code === 11000){
            res.status(409).json({error: "User already exists"});
            return;
        }
        res.status(400).json(response);
        return;
    }


    res.status(200).json({message: "User updated successfully"});
};

export default updateUser;
